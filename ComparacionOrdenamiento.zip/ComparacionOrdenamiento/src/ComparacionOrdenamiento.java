import java.util.*;

interface Ordenador {
    void ordenar(double[] arr);
    String getNombre();
}

class OrdenamientoBurbuja implements Ordenador {
    @Override
    public void ordenar(double[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    double temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    @Override
    public String getNombre() {
        return "Burbuja";
    }
}

class OrdenamientoInsercion implements Ordenador {
    @Override
    public void ordenar(double[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; ++i) {
            double key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
    }

    @Override
    public String getNombre() {
        return "Insercion";
    }
}

class OrdenamientoSeleccion implements Ordenador {
    @Override
    public void ordenar(double[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIdx = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIdx]) {
                    minIdx = j;
                }
            }
            double temp = arr[minIdx];
            arr[minIdx] = arr[i];
            arr[i] = temp;
        }
    }

    @Override
    public String getNombre() {
        return "Seleccion";
    }
}

class OrdenamientoMergeSort implements Ordenador {
    @Override
    public void ordenar(double[] arr) {
        mergesort(arr, 0, arr.length - 1);
    }

    private void mergesort(double[] arr, int l, int r) {
        if (l < r) {
            int m = (l + r) / 2;
            mergesort(arr, l, m);
            mergesort(arr, m + 1, r);
            merge(arr, l, m, r);
        }
    }

    private void merge(double[] arr, int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;

        double[] L = new double[n1];
        double[] R = new double[n2];

        for (int i = 0; i < n1; ++i) {
            L[i] = arr[l + i];
        }
        for (int j = 0; j < n2; ++j) {
            R[j] = arr[m + 1 + j];
        }

        int i = 0, j = 0, k = l;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k++] = L[i++];
            } else {
                arr[k++] = R[j++];
            }
        }

        while (i < n1) {
            arr[k++] = L[i++];
        }

        while (j < n2) {
            arr[k++] = R[j++];
        }
    }

    @Override
    public String getNombre() {
        return "MergeSort";
    }
}

class ComparadorDeTiempos {
    private final List<Ordenador> algoritmos;

    public ComparadorDeTiempos(List<Ordenador> algoritmos) {
        this.algoritmos = algoritmos;
    }

    public void ejecutarComparacion(int[] tamanos) {
        System.out.println("Tabla de tiempos de ejecucion (en milisegundos):");

        
        System.out.printf("%-10s", "Tamaño");
        for (Ordenador ord : algoritmos) {
            System.out.printf("%-15s", ord.getNombre());
        }
        System.out.println();

        
        for (int tamano : tamanos) {
            System.out.printf("%-10d", tamano);
            double[] arregloOriginal = generarArregloAleatorio(tamano);

            for (Ordenador ord : algoritmos) {
                double[] copia = Arrays.copyOf(arregloOriginal, arregloOriginal.length);
                long tiempo = medirTiempo(ord, copia);
                System.out.printf("%-15d", tiempo);
            }
            System.out.println();
        }
    }

    private double[] generarArregloAleatorio(int tamano) {
        Random random = new Random();
        double[] arreglo = new double[tamano];
        for (int i = 0; i < tamano; i++) {
            arreglo[i] = random.nextDouble();
        }
        return arreglo;
    }

    private long medirTiempo(Ordenador ordenador, double[] arr) {
        long inicio = System.nanoTime();
        ordenador.ordenar(arr);
        long fin = System.nanoTime();
        return (fin - inicio) / 1_000_000;
    }
}



public class ComparacionOrdenamiento {
    public static void main(String[] args) {
        int[] tamanos = {100, 500, 1000, 5000, 10000};

        List<Ordenador> algoritmos = Arrays.asList(
            new OrdenamientoBurbuja(),
            new OrdenamientoInsercion(),
            new OrdenamientoSeleccion(),
            new OrdenamientoMergeSort()
        );

        ComparadorDeTiempos comparador = new ComparadorDeTiempos(algoritmos);
        comparador.ejecutarComparacion(tamanos);
    }
}