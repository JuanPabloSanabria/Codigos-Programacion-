package guia4;

import javax.swing.Timer;
import java.util.Random;
import javax.swing.JOptionPane;


public class GUI extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GUI.class.getName());

    Timer timer;
    boolean corriendo = false;
    int[] posiciones = new int[10];
    int[] velocidades = new int[10];
    long tiempoInicio;
    int apuesta = -1;

    public GUI() {
        initComponents();
        for (int i = 1; i <= 10; i++) {
            comboApuesta.addItem("Vehículo " + i);
        }
        sliderVelocidad.setMinimum(10);
        sliderVelocidad.setMaximum(200);
        sliderVelocidad.setValue(100);
    sliderVelocidad.addChangeListener(e -> {
    if (timer != null && timer.isRunning()) {
        timer.setDelay(sliderVelocidad.getValue());
    }
});

    }

    private void iniciarCarrera() {
        if (corriendo) return;
        corriendo = true;
        btnIniciar.setText("En curso...");
        lblResultado.setText("¡La carrera ha comenzado!");

        Random r = new Random();
        for (int i = 0; i < 10; i++) {
            posiciones[i] = 0;
            velocidades[i] = r.nextInt(8) + 5;
        }
        apuesta = comboApuesta.getSelectedIndex();
        tiempoInicio = System.currentTimeMillis();

    timer = new Timer(sliderVelocidad.getValue(), new java.awt.event.ActionListener() {
    @Override
    public void actionPerformed(java.awt.event.ActionEvent e) {
        moverAutos();
    }
    });
    timer.start();

    }

    private void moverAutos() {
        int ganador =-1;
        boolean fin = false;
        for (int i = 0; i < 10; i++) {
            posiciones[i] += velocidades[i];
            if (posiciones[i] >= 750 && ganador == -1){
                ganador = i;
                fin = true;
            }
        }

        panel2.setPosiciones(posiciones);
        panel2.repaint();

        if (fin) {
            timer.stop();
            corriendo = false;
            mostrarGanador(ganador);
        }
    }

    private void mostrarGanador(int ganador) {
int maxPos = 0;
    for (int i = 1; i < 10; i++) {
        if (posiciones[i] > posiciones[maxPos]) {
            maxPos = i;
        }
    }

    java.util.List<Integer> empatados = new java.util.ArrayList<>();
    for (int i = 0; i < 10; i++) {
        if (posiciones[i] == posiciones[maxPos]) {
            empatados.add(i);
        }
    }
    
       boolean huboEmpate = false;

    if (empatados.size() > 1) {
        huboEmpate=true;
        ganador = empatados.get(new java.util.Random().nextInt(empatados.size()));
        System.out.println("Empate detectado entre: " + empatados + " ganador al azar: " + (ganador + 1));
    } else {
        ganador = maxPos;
    }
        String mensaje = "El ganador fue el Vehículo " + (ganador + 1);
        if (huboEmpate) {
        mensaje += " (hubo empate, se eligio al azar).";
    }
        lblResultado.setText(mensaje);

        if (apuesta == ganador) {
            JOptionPane.showMessageDialog(this, "Tu apuesta gano", "Resultado", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Tu vehículo perdio\n" + mensaje, "Resultado", JOptionPane.WARNING_MESSAGE);
        }

        btnIniciar.setText("Iniciar carrera");
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel2 = new guia4.Panel();
        btnIniciar = new javax.swing.JButton();
        comboApuesta = new javax.swing.JComboBox<>();
        sliderVelocidad = new javax.swing.JSlider();
        lblResultado = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 910, Short.MAX_VALUE)
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 706, Short.MAX_VALUE)
        );

        btnIniciar.setBackground(new java.awt.Color(102, 255, 0));
        btnIniciar.setFont(new java.awt.Font("ROG Fonts STRIX SCAR", 0, 14)); // NOI18N
        btnIniciar.setForeground(new java.awt.Color(0, 0, 0));
        btnIniciar.setText("Iniciar");
        btnIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIniciarActionPerformed(evt);
            }
        });

        comboApuesta.setFont(new java.awt.Font("DialogInput", 1, 14)); // NOI18N
        comboApuesta.setForeground(new java.awt.Color(255, 0, 51));
        comboApuesta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboApuestaActionPerformed(evt);
            }
        });

        sliderVelocidad.setPaintTicks(true);
        sliderVelocidad.setToolTipText("");
        sliderVelocidad.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        sliderVelocidad.setInverted(true);

        lblResultado.setFont(new java.awt.Font("SimSun", 3, 18)); // NOI18N
        lblResultado.setForeground(new java.awt.Color(255, 0, 51));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(comboApuesta, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnIniciar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblResultado, javax.swing.GroupLayout.PREFERRED_SIZE, 663, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sliderVelocidad, javax.swing.GroupLayout.PREFERRED_SIZE, 768, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(84, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sliderVelocidad, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(comboApuesta, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                    .addComponent(lblResultado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(194, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarActionPerformed
          iniciarCarrera();
    }//GEN-LAST:event_btnIniciarActionPerformed

    private void comboApuestaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboApuestaActionPerformed
     
    }//GEN-LAST:event_comboApuestaActionPerformed

    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(() -> new GUI().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnIniciar;
    private javax.swing.JComboBox<String> comboApuesta;
    private javax.swing.JLabel lblResultado;
    private guia4.Panel panel2;
    private javax.swing.JSlider sliderVelocidad;
    // End of variables declaration//GEN-END:variables
}
