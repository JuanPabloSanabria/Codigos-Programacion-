package matriz;
import java.util.Scanner;

public class ProgramaMatematico {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            boolean salir = false;
            
            while (!salir) {
                System.out.println("\n--- MENU ---");
                System.out.println("1. Suma de matrices");
                System.out.println("2. Producto de matrices");
                System.out.println("3. Inversa de una matriz");
                System.out.println("4. Producto de matriz por vector");
                System.out.println("5. Salir");
                System.out.print("Seleccione una opcion: ");
                int opcion = sc.nextInt();
                
                switch (opcion) {
                    case 1 -> {
                        Matriz A = Matriz.desdeUsuario(sc, "A");
                        Matriz B = Matriz.desdeUsuario(sc, "B");
                        Matriz suma = A.sumar(B);
                        if (suma != null) {
                            System.out.println("Resultado de la suma:");
                            suma.mostrar();
                        }
                    }
                    case 2 -> {
                        Matriz A = Matriz.desdeUsuario(sc, "A");
                        Matriz B = Matriz.desdeUsuario(sc, "B");
                        Matriz producto = A.multiplicar(B);
                        if (producto != null) {
                            System.out.println("Resultado del producto:");
                            producto.mostrar();
                        }
                    }
                    case 3 -> {
                        Matriz A = Matriz.desdeUsuario(sc, "A");
                        Matriz inversa = A.invertir();
                        if (inversa != null) {
                            System.out.println("Inversa de la matriz:");
                            inversa.mostrar();
                        }
                    }
                    case 4 -> {
                        Matriz A = Matriz.desdeUsuario(sc, "A");
                        System.out.print("Ingrese la dimension del vector: ");
                        int n = sc.nextInt();
                        double[] vector = new double[n];
                        for (int i = 0; i < n; i++) {
                            System.out.print("Elemento [" + i + "]: ");
                            vector[i] = sc.nextDouble();
                        }
                        
                        double[] resultado = A.multiplicarPorVector(vector);
                        if (resultado != null) {
                            System.out.println("Resultado:");
                            for (double v : resultado) {
                                System.out.printf("%8.3f\n", v);
                            }
                        }
                    }
                    case 5 -> {
                        salir = true;
                        System.out.println("Saliendo del programa.");
                    }
                    default -> System.out.println("Opcion invalida.");
                }
            }
        }
    }
    }