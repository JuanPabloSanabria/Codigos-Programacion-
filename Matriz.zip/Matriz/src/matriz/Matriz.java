package matriz;
import java.util.Scanner;

public class Matriz {
     private final double[][] datos;
    private final int filas;
    private final int columnas;

    public Matriz(int filas, int columnas) {
        this.filas = filas;
        this.columnas = columnas;
        datos = new double[filas][columnas];
    }

    public static Matriz desdeUsuario(Scanner sc, String nombre) {
        System.out.print("Ingrese numero de filas de la matriz " + nombre + ": ");
        int filas = sc.nextInt();
        System.out.print("Ingrese numero de columnas de la matriz " + nombre + ": ");
        int columnas = sc.nextInt();

        Matriz matriz = new Matriz(filas, columnas);
        System.out.println("Ingrese los elementos de la matriz " + nombre + ":");
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print("Elemento [" + i + "][" + j + "]: ");
                matriz.datos[i][j] = sc.nextDouble();
            }
        }
        return matriz;
    }

    public Matriz sumar(Matriz otra) {
        if (this.filas != otra.filas || this.columnas != otra.columnas) {
            System.out.println("Las matrices deben tener las mismas dimensiones.");
            return null;
        }

        Matriz resultado = new Matriz(filas, columnas);
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                resultado.datos[i][j] = this.datos[i][j] + otra.datos[i][j];
            }
        }
        return resultado;
    }

    public Matriz multiplicar(Matriz otra) {
        if (this.columnas != otra.filas) {
            System.out.println("Numero de columnas de la primera matriz debe ser igual al numero de filas de la segunda.");
            return null;
        }

        Matriz resultado = new Matriz(this.filas, otra.columnas);
        for (int i = 0; i < this.filas; i++) {
            for (int j = 0; j < otra.columnas; j++) {
                for (int k = 0; k < this.columnas; k++) {
                    resultado.datos[i][j] += this.datos[i][k] * otra.datos[k][j];
                }
            }
        }
        return resultado;
    }

    public Matriz invertir() {
        if (filas != columnas) {
            System.out.println("Solo se puede invertir una matriz cuadrada.");
            return null;
        }

        int n = filas;
        Matriz inversa = new Matriz(n, n);
        double[][] temp = new double[n][2 * n];

        // Copiar datos y agregar identidad
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                temp[i][j] = datos[i][j];
                temp[i][j + n] = (i == j) ? 1 : 0;
            }
        }

        // Método de Gauss-Jordan
        for (int i = 0; i < n; i++) {
            double pivote = temp[i][i];
            if (pivote == 0) {
                System.out.println("La matriz no es invertible.");
                return null;
            }

            for (int j = 0; j < 2 * n; j++) {
                temp[i][j] /= pivote;
            }

            for (int k = 0; k < n; k++) {
                if (k != i) {
                    double factor = temp[k][i];
                    for (int j = 0; j < 2 * n; j++) {
                        temp[k][j] -= factor * temp[i][j];
                    }
                }
            }
        }

        // Extraer parte derecha (la inversa)
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                inversa.datos[i][j] = temp[i][j + n];
            }
        }

        return inversa;
    }

    public double[] multiplicarPorVector(double[] vector) {
        if (columnas != vector.length) {
            System.out.println("Tamaño del vector no compatible con la matriz.");
            return null;
        }

        double[] resultado = new double[filas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                resultado[i] += datos[i][j] * vector[j];
            }
        }
        return resultado;
    }

    public void mostrar() {
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.printf("%8.3f", datos[i][j]);
            }
            System.out.println();
        }
    }
}

