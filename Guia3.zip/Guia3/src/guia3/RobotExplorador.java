package guia3;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Stack;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

public class RobotExplorador extends javax.swing.JFrame {
    DefaultTableModel modelo=new DefaultTableModel();
    Stack<Tarea> pila=new Stack<>();
    
    Timer tiempo = new Timer (1000, new ActionListener (){
    public void actionPerformed(ActionEvent e){
        metodo();
    }
    });
    private Tarea tareaActual = null;

    private static class Tarea {
        String tipo;
        int tiempoRestante;

        Tarea(String tipo, int tiempo) {
            this.tipo = tipo;
            this.tiempoRestante = tiempo;
        }
         public String toString(){
        return tipo + " (" + tiempoRestante + "s) ";
    }
    }
    
    public void metodo (){
        if (tareaActual != null){
            tareaActual.tiempoRestante--;
            Actualizar();
            
            if (tareaActual.tiempoRestante <=0){
                jTextField1.setText("Tarea " + tareaActual.tipo + "completa.");
                tareaActual = null;
                }
        }
        if (tareaActual == null && !pila.isEmpty()){
            tareaActual = pila.pop();
            Actualizar();
        }
        if (tareaActual == null && pila.isEmpty()){
            jTextField1.setText("Sin tareas pendientes");
            tiempo.stop();
        }
        actualizarPila();
    }
    
    private void Actualizar() { 
        if (tareaActual !=null){
            jTextField1.setText("Ejecutando " + tareaActual.tipo +" - Tiempo restante: " + tareaActual.tiempoRestante + " seg");
        }
    }
    
    private void actualizarPila(){
        modelo.setRowCount(0);
        for (int i= pila.size() - 1 ; i>= 0; i--){
            Tarea t = pila.get(i);
            modelo.addRow(new Object []{t.tipo, t.tiempoRestante});
        }
        while(modelo.getRowCount()<10){
            modelo.addRow(new Object[]{" ", " "});
        }
    }

    public RobotExplorador() {
        initComponents();
        modelo.addColumn("Tipo de tarea");
        modelo.addColumn("Tiempo (s)");
        modelo.setColumnCount(2);
        modelo.setRowCount(10);
        jTextField1.setText("Preparado");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 0)));
        jTable1.setFont(new java.awt.Font("Rockwell", 0, 12)); // NOI18N
        jTable1.setForeground(new java.awt.Color(0, 0, 0));
        jTable1.setModel(modelo);
        jScrollPane1.setViewportView(jTable1);

        jButton1.setBackground(new java.awt.Color(51, 255, 51));
        jButton1.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 0));
        jButton1.setText("Iniciar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTextField1.setBackground(new java.awt.Color(255, 102, 255));
        jTextField1.setFont(new java.awt.Font("SWRomnt", 0, 12)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(0, 0, 0));
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.setText("jTextField1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 443, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(46, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     for (int row = 0; row < modelo.getRowCount(); row++) {
            Object tipoObj = modelo.getValueAt(row, 0);
            Object tiempoObj = modelo.getValueAt(row, 1);

            if (tipoObj != null && !tipoObj.toString().trim().isEmpty() &&
                tiempoObj != null && !tiempoObj.toString().trim().isEmpty()) {
                try {
                    String tipo = tipoObj.toString().trim();
                    int tiempoT = Integer.parseInt(tiempoObj.toString().trim());

                    if (tiempoT > 0 && (tipo.equals("ts") || tipo.equals("tc"))) {
                        if (tareaActual == null) {
                            tareaActual = new Tarea(tipo, tiempoT);
                            Actualizar();
                        } else {
                            pila.push(new Tarea(tipo, tiempoT));
                        }
                    }
                } catch (NumberFormatException ex) {
                }
            }
        }

        actualizarPila();

        if (!tiempo.isRunning()) {
            tiempo.start();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
     
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new RobotExplorador().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
