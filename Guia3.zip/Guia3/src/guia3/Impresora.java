package guia3;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Queue;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

public class Impresora extends javax.swing.JFrame {
    DefaultTableModel modelo=new DefaultTableModel();
    Queue<Documento> cola=new LinkedList<>();
    
    Timer tiempo = new Timer (1000, new ActionListener (){
    public void actionPerformed(ActionEvent e){
        metodo();
    }
    });
    private Documento documentoActual = null;
    private int paginaActual = 0;

    private static class Documento {
        String nombre;
        int paginas;

        Documento(String nombre, int paginas) {
            this.nombre = nombre;
            this.paginas = paginas;
        }
    }
    
    public void metodo (){
        if (documentoActual != null){
            paginaActual++;
            Actualizar();
            
            if (paginaActual >= documentoActual.paginas){
                jTextField1.setText("Impresion " + documentoActual.nombre + "completa.");
                documentoActual = null;
                paginaActual=0;
                jProgressBar1.setValue(0);
                }
        }
        if (documentoActual == null && !cola.isEmpty()){
            documentoActual = cola.poll();
            paginaActual = 0;
            jProgressBar1.setMaximum(documentoActual.paginas);
            jProgressBar1.setValue(0);
            Actualizar();
            modelo.removeRow(0);
            modelo.addRow(new Object[] {"",""});
        }
        if (documentoActual == null && cola.isEmpty()){
            jTextField1.setText("Sin documentos en cola");
        }
    }
    
    private void Actualizar() { 
        jProgressBar1.setValue(paginaActual);
        jTextField1.setText("Imprimiendo " + documentoActual.nombre + " - Pagina " + paginaActual + " de " + documentoActual.paginas);
    }
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Impresora.class.getName());

    public Impresora() {
        initComponents();
        modelo.addColumn("Nombre");
        modelo.addColumn("Paginas");
        modelo.setColumnCount(2);
        modelo.setRowCount(10);
        jTextField1.setText("Preparado para impresión");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jProgressBar1 = new javax.swing.JProgressBar();
        jButton1 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 0)));
        jTable1.setFont(new java.awt.Font("Rockwell", 0, 12)); // NOI18N
        jTable1.setForeground(new java.awt.Color(0, 0, 0));
        jTable1.setModel(modelo);
        jScrollPane1.setViewportView(jTable1);

        jProgressBar1.setBackground(new java.awt.Color(0, 102, 255));
        jProgressBar1.setForeground(new java.awt.Color(153, 153, 255));
        jProgressBar1.setMaximum(9);
        jProgressBar1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jProgressBar1StateChanged(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(51, 255, 51));
        jButton1.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 0));
        jButton1.setText("Iniciar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTextField1.setBackground(new java.awt.Color(51, 255, 255));
        jTextField1.setFont(new java.awt.Font("SWRomnt", 0, 12)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(0, 0, 0));
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.setText("jTextField1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jProgressBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 388, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jProgressBar1, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         for (int row = 0; row < modelo.getRowCount(); row++) {
        Object nombreObj = modelo.getValueAt(row, 0);
        Object paginasObj = modelo.getValueAt(row, 1);

        if (nombreObj != null && !nombreObj.toString().trim().isEmpty() &&
            paginasObj != null && !paginasObj.toString().trim().isEmpty()) {
            try {
                String nombre = nombreObj.toString().trim();
                int paginas = Integer.parseInt(paginasObj.toString().trim());
                if (paginas > 0) {
                    cola.add(new Documento(nombre, paginas));
                }
            } catch (NumberFormatException ex) {
            }
        }
    }
        tiempo.start();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jProgressBar1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jProgressBar1StateChanged
        
    }//GEN-LAST:event_jProgressBar1StateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Impresora().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
