package guia4;
    
import java.awt.Color;
import java.awt.Graphics;
    
public class Panel extends javax.swing.JPanel {
    private int[] posiciones = new int[10];     
    public Panel() {
        initComponents();
    }
     public void setPosiciones(int[] pos) {
        if (pos == null) return;
        if (pos.length >= 10) {
            for (int i = 0; i < 10; i++) this.posiciones[i] = pos[i];
        } else {
            for (int i = 0; i < 10; i++) this.posiciones[i] = (i < pos.length) ? pos[i] : 0;
        }
    }

    @Override
    public void paintComponent(Graphics p){
        super.paintComponent(p);
        Color miColor = new Color(220, 220, 50);
        p.setColor(miColor);
        p.fillRect(posiciones[0], 10, 50, 40);
        p.setColor(Color.BLACK);
        p.fillRect(posiciones[0], 0, 10, 10);
        p.fillRect(posiciones[0], 50, 10, 10);

        Color miColor1 = new Color(100, 100, 25);
        p.setColor(miColor1);
        p.fillRect(posiciones[1], 80, 50, 40);
        p.setColor(Color.BLACK);
        p.fillRect(posiciones[1], 70, 10, 10);
        p.fillRect(posiciones[1], 120, 10, 10);

        Color miColor2 = new Color(170, 250, 20);
        p.setColor(miColor2);
        p.fillRect(posiciones[2], 150, 50, 40);
        p.setColor(Color.BLACK);
        p.fillRect(posiciones[2], 140, 10, 10);
        p.fillRect(posiciones[2], 190, 10, 10);

        Color miColor3 = new Color(40, 50, 250);
        p.setColor(miColor3);
        p.fillRect(posiciones[3], 220, 50, 40);
        p.setColor(Color.BLACK);
        p.fillRect(posiciones[3], 210, 10, 10);
        p.fillRect(posiciones[3], 260, 10, 10);

        Color miColor4 = new Color(20, 220, 250);
        p.setColor(miColor4);
        p.fillRect(posiciones[4], 290, 50, 40);
        p.setColor(Color.BLACK);
        p.fillRect(posiciones[4], 280, 10, 10);
        p.fillRect(posiciones[4], 330, 10, 10);

        Color miColor5 = new Color(120, 120, 25);
        p.setColor(miColor5);
        p.fillRect(posiciones[5], 360, 50, 40);
        p.setColor(Color.BLACK);
        p.fillRect(posiciones[5], 350, 10, 10);
        p.fillRect(posiciones[5], 400, 10, 10);

        Color miColor6 = new Color(220, 250, 200);
        p.setColor(miColor6);
        p.fillRect(posiciones[6], 430, 50, 40);
        p.setColor(Color.BLACK);
        p.fillRect(posiciones[6], 420, 10, 10);
        p.fillRect(posiciones[6], 470, 10, 10);

        Color miColor7 = new Color(250, 150, 25);
        p.setColor(miColor7);
        p.fillRect(posiciones[7], 500, 50, 40);
        p.setColor(Color.BLACK);
        p.fillRect(posiciones[7], 490, 10, 10);
        p.fillRect(posiciones[7], 540, 10, 10);

        Color miColor8 = new Color(20, 250, 20);
        p.setColor(miColor8);
        p.fillRect(posiciones[8], 570, 50, 40);
        p.setColor(Color.BLACK);
        p.fillRect(posiciones[8], 560, 10, 10);
        p.fillRect(posiciones[8], 610, 10, 10);

        Color miColor9 = new Color(150, 100, 250);
        p.setColor(miColor9);
        p.fillRect(posiciones[9], 640, 50, 40);
        p.setColor(Color.BLACK);
        p.fillRect(posiciones[9], 630, 10, 10);
        p.fillRect(posiciones[9], 680, 10, 10);
        
        p.setColor(Color.BLACK);
        p.fillRect(800, 0, 100, 700);
        
        for (int i=0 ; i<680 ; i=i+100){
            p.setColor(Color.WHITE);
            p.fillRect(800, i, 50, 50);
        }
         for (int i=0 ; i<680 ; i=i+100){
            p.setColor(Color.WHITE);
            p.fillRect(850, i+50, 50, 50);
        }
    }
     

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
