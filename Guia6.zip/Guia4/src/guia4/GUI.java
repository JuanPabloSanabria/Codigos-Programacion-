package guia4;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.Random;
import javax.swing.SwingUtilities;

public class GUI extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GUI.class.getName());

    Timer timer;
    boolean corriendo = false; //evita iniciar la carrera dos veces.
    int[] posiciones = new int[10];
    int[] velocidades = new int[10];
    long[] tiemposLlegada = new long[10];
    boolean[] llego = new boolean[10];
    int autosTerminados = 0;
    int apuesta = -1;
    long tiempoInicio;

    public GUI() {
        initComponents();
        comboApuesta.removeAllItems();
        for (int i = 1; i <= 10; i++) {
            comboApuesta.addItem("Vehiculo " + i);
        }

        sliderVelocidad.setMinimum(10);
        sliderVelocidad.setMaximum(200);
        sliderVelocidad.setValue(100);
         sliderVelocidad.addChangeListener(e -> {
        if (timer != null && corriendo) {
            timer.setDelay(sliderVelocidad.getValue());
        }
    });
    }

private Thread[] hilosVehiculos = new Thread[10];

private void iniciarCarrera() {
    if (corriendo) return;
    corriendo = true;
    btnIniciar.setText("En curso ...");
    autosTerminados = 0;

    for (int i = 0; i < 10; i++) {
        posiciones[i] = 0;
        llego[i] = false;
        tiemposLlegada[i] = 0;
    }

    Random r = new Random();
    for (int i = 0; i < 10; i++) {
        velocidades[i] = r.nextInt(6) + 4; // entre 4 y 9 pixels
    }

    apuesta = comboApuesta.getSelectedIndex();
    tiempoInicio = System.currentTimeMillis();

    for (int i = 0; i < 10; i++) {
        hilosVehiculos[i] = new VehiculoHilo( i, posiciones, velocidades, tiemposLlegada, llego, panel2, tiempoInicio, sliderVelocidad);
        hilosVehiculos[i].start();
    }

    Thread monitorHilo = new Thread(() -> {
        try {
            for (int i = 0; i < 10; i++) {
                hilosVehiculos[i].join();
            }
            SwingUtilities.invokeLater(() -> {
                corriendo = false;
                mostrarTablaResultados();
            });
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    });
    monitorHilo.start();
}

    private void mostrarTablaResultados() {

        String[] columnas = {"Vehiculo", "Tiempo (segundos)"};
        Object[][] datos = new Object[10][2];

        for (int i = 0; i < 10; i++) {
            datos[i][0] = "Vehiculo " + (i + 1);
            datos[i][1] = String.format("%.2f", tiemposLlegada[i] / 1000.0);
        }

        for (int i = 0; i < 9; i++) {
            for (int j = i + 1; j < 10; j++) {
                if (tiemposLlegada[i] > tiemposLlegada[j]) {
           long tmpT = tiemposLlegada[i];
                    tiemposLlegada[i] = tiemposLlegada[j];
                    tiemposLlegada[j] = tmpT;

                    String tmpV = (String) datos[i][0];
                    datos[i][0] = datos[j][0];
                    datos[j][0] = tmpV;

                    Object tmpO = datos[i][1];
                    datos[i][1] = datos[j][1];
                    datos[j][1] = tmpO;
                }
            }
        }
double mejorTiempo = tiemposLlegada[0];
java.util.List<Integer> empatados = new java.util.ArrayList<>();
empatados.add(0);

// Detecta empates (menos de 50 ms de diferencia)
for (int i = 1; i < 10; i++) {
    if (Math.abs(tiemposLlegada[i] - mejorTiempo) < 50) {
        empatados.add(i);
    }
}

String mensajeFinal;
if (empatados.size() > 1) {
    int elegido = empatados.get(new Random().nextInt(empatados.size()));
    mensajeFinal = "Empate entre " + empatados.size() + " vehiculos.\n" + "Se eligio al " + datos[elegido][0] + " como ganador al azar.";
} else {
    mensajeFinal = "El ganador fue el " + datos[0][0];
}

lblResultado.setText(mensajeFinal);

        DefaultTableModel modelo = new DefaultTableModel(datos, columnas);
        JTable tabla = new JTable(modelo);

        JScrollPane scroll = new JScrollPane(tabla);
        JOptionPane.showMessageDialog(this, scroll, "Resultados de la Carrera", JOptionPane.INFORMATION_MESSAGE);

        String ganador = lblResultado.getText();

        int numeroGanador = Integer.parseInt(ganador.split(" ")[1]) - 1;

        if (apuesta == numeroGanador) {
            JOptionPane.showMessageDialog(this, "Tu apuesta gana (" + ganador + ")", "Resultado", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Tu vehículo perdio.\nGanó " + ganador, "Resultado", JOptionPane.WARNING_MESSAGE);
        }

        btnIniciar.setText("Iniciar carrera");
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        panel2 = new guia4.Panel();
        btnIniciar = new javax.swing.JButton();
        comboApuesta = new javax.swing.JComboBox<>();
        sliderVelocidad = new javax.swing.JSlider();
        lblResultado = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 910, Short.MAX_VALUE)
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 706, Short.MAX_VALUE)
        );

        btnIniciar.setBackground(new java.awt.Color(102, 255, 0));
        btnIniciar.setFont(new java.awt.Font("ROG Fonts STRIX SCAR", 0, 14)); // NOI18N
        btnIniciar.setForeground(new java.awt.Color(0, 0, 0));
        btnIniciar.setText("Iniciar");
        btnIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIniciarActionPerformed(evt);
            }
        });

        comboApuesta.setFont(new java.awt.Font("DialogInput", 1, 14)); // NOI18N
        comboApuesta.setForeground(new java.awt.Color(255, 0, 51));
        comboApuesta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboApuestaActionPerformed(evt);
            }
        });

        sliderVelocidad.setPaintTicks(true);
        sliderVelocidad.setToolTipText("");
        sliderVelocidad.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        sliderVelocidad.setInverted(true);

        lblResultado.setFont(new java.awt.Font("SimSun", 3, 18)); // NOI18N
        lblResultado.setForeground(new java.awt.Color(255, 0, 51));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(comboApuesta, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnIniciar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(sliderVelocidad, javax.swing.GroupLayout.DEFAULT_SIZE, 768, Short.MAX_VALUE)
                            .addComponent(lblResultado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(84, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(sliderVelocidad, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnIniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(comboApuesta, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                    .addComponent(lblResultado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(309, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarActionPerformed
          iniciarCarrera();
    }//GEN-LAST:event_btnIniciarActionPerformed

    private void comboApuestaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboApuestaActionPerformed
     
    }//GEN-LAST:event_comboApuestaActionPerformed

    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(() -> new GUI().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnIniciar;
    private javax.swing.JComboBox<String> comboApuesta;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblResultado;
    private guia4.Panel panel2;
    private javax.swing.JSlider sliderVelocidad;
    // End of variables declaration//GEN-END:variables
}
