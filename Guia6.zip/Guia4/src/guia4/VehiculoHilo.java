package guia4;

public class VehiculoHilo extends Thread {
    private int idVehiculo;
    private int[] posiciones;
    private int[] velocidades;
    private long[] tiemposLlegada;
    private boolean[] llego;
    private Panel panel;
    private long tiempoInicio;
    private javax.swing.JSlider sliderVelocidad;
    private static final int META = 750;

    public VehiculoHilo(int id, int[] posiciones, int[] velocidades, long[] tiemposLlegada, boolean[] llego, Panel panel, long tiempoInicio, javax.swing.JSlider sliderVelocidad) {
        this.idVehiculo = id;
        this.posiciones = posiciones;
        this.velocidades = velocidades;
        this.tiemposLlegada = tiemposLlegada;
        this.llego = llego;
        this.panel = panel;
        this.tiempoInicio = tiempoInicio;
        this.sliderVelocidad = sliderVelocidad;
    }

    @Override
    public void run() {
        while (!llego[idVehiculo]) {
            synchronized (posiciones) {
                posiciones[idVehiculo] += velocidades[idVehiculo];
                if (posiciones[idVehiculo] >= META) {
                    posiciones[idVehiculo] = META;
                    llego[idVehiculo] = true;
                    tiemposLlegada[idVehiculo] = System.currentTimeMillis() - tiempoInicio;
                }
            }
            panel.setPosiciones(posiciones);
            panel.repaint();
            try {
                Thread.sleep(sliderVelocidad.getValue());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
