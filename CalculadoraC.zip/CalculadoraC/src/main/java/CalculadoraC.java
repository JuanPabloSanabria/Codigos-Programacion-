import java.util.Scanner;

public class CalculadoraC {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Almacenador dinamico como cin>>
        int opcion; 
        double num1, num2, resultado;

        do {
            System.out.println("\n---------- Calculadora ----------");
            System.out.println("1. Suma");
            System.out.println("2. Resta");
            System.out.println("3. Multiplicacion");
            System.out.println("4. Division");
            System.out.println("5. Seno");
            System.out.println("6. Coseno");
            System.out.println("7. Tangente");
            System.out.println("8. Raiz");
            System.out.println("9. Potencia");
            System.out.println("10. IVA");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese primer numero: ");
                    num1 = scanner.nextDouble();
                    System.out.print("Ingrese segundo numero: ");
                    num2 = scanner.nextDouble();
                    resultado = num1 + num2;
                    System.out.println("Resultado: " + resultado);
                    break;

                case 2: 
                    System.out.print("Ingrese primer numero: ");
                    num1 = scanner.nextDouble();
                    System.out.print("Ingrese segundo numero: ");
                    num2 = scanner.nextDouble();
                    resultado = num1 - num2;
                    System.out.println("Resultado: " + resultado);
                    break;

                case 3:
                    System.out.print("Ingrese primer numero: ");
                    num1 = scanner.nextDouble();
                    System.out.print("Ingrese segundo numero: ");
                    num2 = scanner.nextDouble();
                    resultado = num1 * num2;
                    System.out.println("Resultado: " + resultado);
                    break;

                case 4:
                    System.out.print("Ingrese primer numero: ");
                    num1 = scanner.nextDouble();
                    System.out.print("Ingrese segundo numero: ");
                    num2 = scanner.nextDouble();
                    if (num2 != 0) {
                        resultado = num1 / num2;
                        System.out.println("Resultado: " + resultado);
                    } else {
                        System.out.println("Error");
                    }
                    break;

                case 5: 
                    System.out.print("Ingrese angulo en grados: ");
                    num1 = scanner.nextDouble();
                    resultado = Math.sin(Math.toRadians(num1)); //Esta hace la conversion de grados a radianes
                    System.out.println("Seno de " + num1 + "° = " + resultado);
                    break;

                case 6: 
                    System.out.print("Ingrese angulo en grados: ");
                    num1 = scanner.nextDouble();
                    resultado = Math.cos(Math.toRadians(num1));
                    System.out.println("Coseno de " + num1 + "° = " + resultado);
                    break;

                case 7: 
                    System.out.print("Ingrese angulo en grados: ");
                    num1 = scanner.nextDouble();
                    resultado = Math.tan(Math.toRadians(num1));
                    System.out.println("Tangente de " + num1 + "° = " + resultado);
                    break;

                case 8: 
                    System.out.print("Ingrese el numero: ");
                    num1 = scanner.nextDouble();
                    System.out.print("Ingrese el indice de la raiz: ");
                    num2 = scanner.nextDouble();
                    if (num1 >= 0 ) {
                        resultado = Math.pow(num1, 1.0 / num2); //Eleva el numero de la potencia con "1/" generando una raiz
                        System.out.println("Raiz " + num2 + " de " + num1 + " = " + resultado);
                    } else {
                        System.out.println("Error");
                    }
                    break;

                case 9: 
                    System.out.print("Ingrese la base: ");
                    num1 = scanner.nextDouble();
                    System.out.print("Ingrese el exponente: ");
                    num2 = scanner.nextDouble();
                    resultado = Math.pow(num1, num2);
                    System.out.println(num1 + " elevado a " + num2 + " = " + resultado);
                    break;

                case 10:
                    System.out.print("Ingrese el precio: ");
                    num1 = scanner.nextDouble();
                    System.out.print("Ingrese el porcentaje de IVA: ");
                    num2 = scanner.nextDouble();
                    resultado = num1 * (num2 / 100);
                    System.out.println("IVA (" + num2 + "%): " + resultado);
                    System.out.println("Monto total con IVA: " + (num1 + resultado));
                    break;

                case 0:
                    break;
            }
        } while (opcion != 0);
        scanner.close();
    }
}